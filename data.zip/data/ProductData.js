// src/data/ProductData.js

const ProductData = {
    men: [
      // Glasses
      { id: "1", category: "Men's Glasses", name: "Ray-Ban Classic", price: "$120.00", image: require("../assets/G1.png"), liked: false },
      { id: "2", category: "Men's Glasses", name: "Oakley Modern", price: "$150.00", image: require("../assets/G2.png"), liked: false },
      { id: "3", category: "Men's Glasses", name: "Gucci Round", price: "$200.00", image: require("../assets/G4.png"), liked: false },
      { id: "4", category: "Men's Glasses", name: "Tom Ford Chic", price: "$180.00", image: require("../assets/G6.png"), liked: false },
      // Watches
      { id: "5", category: "Men's Watches", name: "Rolex Submariner", price: "$5,000.00", image: require("../assets/W1.png"), liked: false },
      { id: "6", category: "Men's Watches", name: "Casio Edifice", price: "$250.00", image: require("../assets/W2.png"), liked: false },
      { id: "7", category: "Men's Watches", name: "Seiko Sports", price: "$300.00", image: require("../assets/W2.png"), liked: false },
      { id: "8", category: "Men's Watches", name: "Omega Speedmaster", price: "$6,000.00", image: require("../assets/W2.png"), liked: false },
      // Hats
      { id: "9", category: "Men's Hats", name: "Baseball Cap", price: "$25.00", image: require("../assets/Hats.png"), liked: false },
      { id: "10", category: "Men's Hats", name: "Fedora Hat", price: "$50.00", image: require("../assets/Hats.png"), liked: false },
      { id: "11", category: "Men's Hats", name: "Cowboy Hat", price: "$60.00", image: require("../assets/Hats.png"), liked: false },
      { id: "12", category: "Men's Hats", name: "Beret Hat", price: "$40.00", image: require("../assets/Hats.png"), liked: false },
    ],
    women: [
      // Glasses
      { id: "1", category: "Women's Glasses", name: "Ray-Ban Classic", price: "$120.00", image: require("../assets/G1.png"), liked: false },
      { id: "2", category: "Women's Glasses", name: "Oakley Modern", price: "$150.00", image: require("../assets/G2.png"), liked: false },
      { id: "3", category: "Women's Glasses", name: "Gucci Round", price: "$200.00", image: require("../assets/G4.png"), liked: false },
      { id: "4", category: "Women's Glasses", name: "Tom Ford Chic", price: "$180.00", image: require("../assets/G6.png"), liked: false },
      // Watches
      { id: "5", category: "Women's Watches", name: "Rolex Submariner", price: "$5,000.00", image: require("../assets/W1.png"), liked: false },
      { id: "6", category: "Women's Watches", name: "Casio Edifice", price: "$250.00", image: require("../assets/W2.png"), liked: false },
      { id: "7", category: "Women's Watches", name: "Seiko Sports", price: "$300.00", image: require("../assets/W2.png"), liked: false },
      { id: "8", category: "Women's Watches", name: "Omega Speedmaster", price: "$6,000.00", image: require("../assets/W2.png"), liked: false },
      // Hats
      { id: "9", category: "Women's Hats", name: "Baseball Cap", price: "$25.00", image: require("../assets/Hats.png"), liked: false },
      { id: "10", category: "Women's Hats", name: "Fedora Hat", price: "$50.00", image: require("../assets/Hats.png"), liked: false },
      { id: "11", category: "Women's Hats", name: "Cowboy Hat", price: "$60.00", image: require("../assets/Hats.png"), liked: false },
      { id: "12", category: "Women's Hats", name: "Beret Hat", price: "$40.00", image: require("../assets/Hats.png"), liked: false },
    ],
    kids: [
      // Glasses
      { id: "1", category: "Kids' Glasses", name: "Ray-Ban Classic", price: "$120.00", image: require("../assets/G1.png"), liked: false },
      { id: "2", category: "Kids' Glasses", name: "Oakley Modern", price: "$150.00", image: require("../assets/G2.png"), liked: false },
      { id: "3", category: "Kids' Glasses", name: "Gucci Round", price: "$200.00", image: require("../assets/G4.png"), liked: false },
      { id: "4", category: "Kids' Glasses", name: "Tom Ford Chic", price: "$180.00", image: require("../assets/G6.png"), liked: false },
      // Watches
      { id: "5", category: "Kids' Watches", name: "Rolex Submariner", price: "$5,000.00", image: require("../assets/W1.png"), liked: false },
      { id: "6", category: "Kids' Watches", name: "Casio Edifice", price: "$250.00", image: require("../assets/W2.png"), liked: false },
      { id: "7", category: "Kids' Watches", name: "Seiko Sports", price: "$300.00", image: require("../assets/W2.png"), liked: false },
      { id: "8", category: "Kids' Watches", name: "Omega Speedmaster", price: "$6,000.00", image: require("../assets/W2.png"), liked: false },
      // Hats
      { id: "9", category: "Kids' Hats", name: "Baseball Cap", price: "$25.00", image: require("../assets/Hats.png"), liked: false },
      { id: "10", category: "Kids' Hats", name: "Fedora Hat", price: "$50.00", image: require("../assets/Hats.png"), liked: false },
      { id: "11", category: "Kids' Hats", name: "Cowboy Hat", price: "$60.00", image: require("../assets/Hats.png"), liked: false },
      { id: "12", category: "Kids' Hats", name: "Beret Hat", price: "$40.00", image: require("../assets/Hats.png"), liked: false },
    ],
    newCollection: [
      { id: "1", category: "New Collection", name: "Stylish Sunglasses", price: "$100.00", image: require("../assets/Hats.png"), liked: false },
      { id: "2", category: "New Collection", name: "Elegant Wristwatch", price: "$400.00", image: require("../assets/Hats.png"), liked: false },
      { id: "3", category: "New Collection", name: "Trendy Hat", price: "$30.00", image: require("../assets/Hats.png"), liked: false },
      { id: "4", category: "New Collection", name: "Luxury Bag", price: "$500.00", image: require("../assets/Hats.png"), liked: false },
    ],
  };
  
  export default ProductData;
  