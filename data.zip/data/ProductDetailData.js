// src/data/ProductDetailData.js

const ProductDetailData = [
  // MEN. Glasses
  {
    id: "1",
    category: "Glasses",
    name: "Ray-Ban Classic",
    price: "$120.00",
    description: "Classic Ray-Ban glasses for a timeless look. These glasses feature high-quality lenses that ensure crystal-clear vision while reducing glare. Their durable frame makes them ideal for everyday wear, while the comfortable nose pads provide a secure fit. Perfect for both casual outings and formal settings, these glasses are a must-have for anyone looking to enhance their style with a touch of elegance.",
    rating: "⭐ 4.5 | 💚 92% (145 reviews)",
    image: require("../assets/G1.png"),
  },
  {
    id: "2",
    category: "Glasses",
    name: "Oakley Modern",
    price: "$150.00",
    description: "Stylish Oakley glasses for a sporty look. Designed with high-impact activities in mind, these glasses offer unparalleled UV protection, shielding your eyes from harmful rays. The lightweight yet sturdy frame provides durability without compromising comfort. With a sleek and modern design, these glasses are perfect for those who lead an active lifestyle while still wanting to maintain a trendy appearance.",
    rating: "⭐ 4.6 | 💚 90% (120 reviews)",
    image: require("../assets/G2.png"),
  },
  {
    id: "3",
    category: "Glasses",
    name: "Gucci Round",
    price: "$200.00",
    description: "Elegant Gucci round glasses for a premium style. Crafted from luxury acetate, these glasses offer superior durability while maintaining a sophisticated look. The distinctive round frame is a timeless design that flatters various face shapes. Adjustable temples provide added comfort, making them perfect for all-day wear. Elevate your accessory collection with these stylish and high-end glasses.",
    rating: "⭐ 4.8 | 💚 95% (200 reviews)",
    image: require("../assets/G4.png"),
  },
  {
    id: "4",
    category: "Glasses",
    name: "Tom Ford Chic",
    price: "$180.00",
    description: "Chic Tom Ford glasses for a sophisticated look. These glasses feature a premium metal frame that offers long-lasting quality and elegance. Anti-glare coated lenses ensure a clear vision even in bright lighting conditions. Soft nose pads add extra comfort, allowing for prolonged use without discomfort. Whether you're heading to a business meeting or a casual day out, these glasses will complement your look effortlessly.",
    rating: "⭐ 4.7 | 💚 93% (180 reviews)",
    image: require("../assets/G6.png"),
  },
];

export default ProductDetailData;
