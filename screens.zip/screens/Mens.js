import React, { useState } from "react";
import { StyleSheet, View, Text, TouchableOpacity, ScrollView, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import Header from "./HeaderNavigation";
import Footer from "./Footer";
import ProductList from "../Components/ProductList"; // Import ProductList component

const Men = () => {
  const [selectedCategory, setSelectedCategory] = useState("Glasses");
  const [cart, setCart] = useState([]); // Cart State
  const navigation = useNavigation();

  // Men's Product Data
  const productList = [
    { id: "1", category: "Glasses", name: "Ray-Ban Classic", price: "$120.00", image: require("../assets/G1.png"), liked: false },
    { id: "2", category: "Glasses", name: "Oakley Modern", price: "$150.00", image: require("../assets/G2.png"), liked: false },
    { id: "3", category: "Glasses", name: "Gucci Round", price: "$200.00", image: require("../assets/G4.png"), liked: false },
    { id: "4", category: "Glasses", name: "Tom Ford Chic", price: "$180.00", image: require("../assets/G6.png"), liked: false },
    { id: "5", category: "Watches", name: "Rolex Submariner", price: "$5,000.00", image: require("../assets/W1.png"), liked: false },
    { id: "6", category: "Watches", name: "Casio Edifice", price: "$250.00", image: require("../assets/W2.png"), liked: false },
    { id: "7", category: "Watches", name: "Seiko Sports", price: "$300.00", image: require("../assets/W2.png"), liked: false },
    { id: "8", category: "Watches", name: "Omega Speedmaster", price: "$6,000.00", image: require("../assets/W2.png"), liked: false },
    { id: "9", category: "Hats", name: "Baseball Cap", price: "$25.00", image: require("../assets/Hats.png"), liked: false },
    { id: "10", category: "Hats", name: "Fedora Hat", price: "$50.00", image: require("../assets/Hats.png"), liked: false },
    { id: "11", category: "Hats", name: "Cowboy Hat", price: "$60.00", image: require("../assets/Hats.png"), liked: false },
    { id: "12", category: "Hats", name: "Beret Hat", price: "$40.00", image: require("../assets/Hats.png"), liked: false },
  ];

  // Filter products based on selected category
  const filteredProducts = productList.filter((product) => product.category === selectedCategory);

  // Add to Cart Function
  const addToCart = (product) => {
    setCart((prevCart) => [...prevCart, product]);
  };

  // Navigate to Product Detail when a product is clicked
  const navigateToProductDetail = (product) => {
    navigation.navigate("ProductDetail", { productId: product.id });
  };

  return (
    <View style={styles.container}>
      {/* Header Component with Cart Count */}
      <Header cartCount={cart.length} />

      <ScrollView contentContainerStyle={styles.contentContainer}>
        {/* Banner Section */}
        <View style={styles.bannerContainer}>
          <Image source={require("../assets/Men b1.png")} style={styles.bannerImage} />
        </View>

        {/* Buttons for Categories */}
        <View style={styles.buttonsContainer}>
          {["Glasses", "Watches", "Hats"].map((category) => (
            <TouchableOpacity
              key={category}
              style={[
                styles.categoryButton,
                selectedCategory === category ? styles.selectedButton : styles.nonSelectedButton,
              ]}
              onPress={() => setSelectedCategory(category)}
            >
              <Text style={selectedCategory === category ? styles.selectedText : styles.nonSelectedText}>
                {category}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Product List Component - Displays Filtered Products */}
        <ProductList 
          data={filteredProducts} 
          addToCart={addToCart} 
          navigateToDetail={navigateToProductDetail} // Pass navigate function to ProductList
        />
      </ScrollView>

      {/* Button to Navigate to Add to Cart Page */}
      <TouchableOpacity
        style={styles.goToCartButton}
        onPress={() => navigation.navigate("AddtoCart", { cart })}
      >
        <Text style={styles.goToCartButtonText}>Go to Cart ({cart.length})</Text>
      </TouchableOpacity>

      {/* Footer Component */}
      <Footer />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  contentContainer: {
    paddingBottom: 80, // Increased padding for smooth scrolling
  },
  bannerContainer: {
    width: "100%",
    height: 200,
  },
  bannerImage: {
    width: "100%",
    height: "100%",
    borderRadius: 10,
    resizeMode: "cover",
  },
  buttonsContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 30,
    paddingHorizontal: 20,
  },
  categoryButton: {
    backgroundColor: "#E46969",
    borderRadius: 25,
    paddingHorizontal: 20,
    paddingVertical: 2,
    marginHorizontal: 10,
    width:100,
  },
  selectedButton: {
    backgroundColor: "#E46969",
  },
  nonSelectedButton: {
    backgroundColor: "#FFF",
    borderWidth: 1,
    borderColor: "#000",
  },
  selectedText: {
    color: "#FFF",
    fontWeight: "bold",
    textAlign: "center",
  },
  nonSelectedText: {
    color: "#000",
    textAlign: "center",
  },
  goToCartButton: {
    position: "absolute",
    bottom: 20,
    left: "20%",
    right: "20%",
    backgroundColor: "#E46969",
    paddingVertical: 10,
    borderRadius: 20,
    alignItems: "center",
    elevation: 3,
  },
  goToCartButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
});

export default Men;
