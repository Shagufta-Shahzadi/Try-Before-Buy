export const green = '#2BB789';
export const darkGreen = '#006A42';
export const Black = '#000';
export const white = "#FFFFFF"